package ex02_허준혁;

public class Print {
	public static void main(String[] args) {
		
//	15부터 30까지 중 짝수의 합을 출력하라
//	- 단, while문을 사용할 것
	//로직
	//짝수들을 담을 수 있는 변수 생성
	//짝수를 담은 변수의  값을 더
		
	int sum =0,count =0;
}
}
