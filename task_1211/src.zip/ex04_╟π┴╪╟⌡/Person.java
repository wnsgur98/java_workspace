package ex04_허준혁;

public class Person {

	//필드
	String name = "학생이름";

	//생성자
	public Person(String name) {
		super();
		this.name = "학생이름";
	}
	//메소드?????
	void preson(String name) {
		
	}
	
}
